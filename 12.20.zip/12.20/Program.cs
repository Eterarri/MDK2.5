﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._20
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] array = getMass(5,4);
            printMass(array);

            Console.Write("Имеются ли четные числа в левом верхнем или в левом нижнем углу: ");
            Console.Write(array[0, 0] % 2 == 0 || array[array.GetLength(0) - 1, 0] % 2 == 0 ? "да" : "нет");
               
            Console.WriteLine();

            Console.Write("Имеются ли числа, оканчивающиеся нулем, в правом верхнем илив правом нижнем углу: ");
            Console.Write(array[0, array.GetLength(1) - 1] % 10 == 0 || array[array.GetLength(0) - 1, array.GetLength(1) - 1] % 10 == 0 ? "да" : "нет");

            Console.ReadKey();
        }
        static int[,] getMass(int row, int colums)
        {
            int[,] array = new int[row,colums];

            Random random = new Random();
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    array[i, j] = random.Next(1,100);
                }
            }
            return array;
        }
        static void printMass(int[,] array)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                    Console.Write(array[i, j] + "\t");
                Console.WriteLine();
                Console.WriteLine();
            }
        }
    }
}
