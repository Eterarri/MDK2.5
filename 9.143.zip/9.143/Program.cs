﻿using System;

namespace _9._143
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ведите число: ");
            Console.Write(int.TryParse(Console.ReadLine(), out int res) ? "Является десятичной записью" : "Не является десятичной записью");
            Console.ReadKey();
        }
    }
}
