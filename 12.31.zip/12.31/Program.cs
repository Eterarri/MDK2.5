﻿
using System;
using System.Collections.Generic;


namespace _12._31
{
    class Program
    {
        static void Main(string[] args)
        {
            printMass(getMass(5,5));
            Console.ReadKey();
        }
        public static List<int> unic = new List<int>();
        public static Random random = new Random();

        static int GetUnical()
        {
            int temp = random.Next(1,100);
            for (int i = 0; i < unic.Count; i++)
                if (temp == unic[i])
                    return GetUnical();
            unic.Add(temp);
            return temp;

        }
        static int[,] getMass(int row, int colums)
        {
            int[,] array = new int[row, colums];


            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    array[i, j] = GetUnical();
                }
            }
            return array;
        }
        static void printMass(int[,] array)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                    Console.Write(array[i, j] + "\t");
                Console.WriteLine();
                Console.WriteLine();
            }
        }
    }
}
