﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8._42
{
    class Program
    {
        static void Main()
        {
            Console.Write("Введите степень => ");
            int n = int.Parse(Console.ReadLine());           
            Console.Write("Введите кол-во повторов => ");
            int m = int.Parse(Console.ReadLine());
            int res = 0;
            for (int i = 1; i < m + 1; i++)
                res += (int)Math.Pow(i, n);
            Console.WriteLine("Результат => " + res);
            Console.ReadKey();
        }
    }
}
