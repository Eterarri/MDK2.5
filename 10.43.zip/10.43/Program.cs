﻿using System;

namespace _9._172
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите число => ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Сумма цифр => " + SumNature(a));
            Console.WriteLine("Количество цифр => " + SumCount(a));
            Console.ReadKey();
        }
        public static int SumNature(int a)
        {
            if (a.ToString().Length == 1)
                return a;        
            int res = a % 10;
            int temp = a / 10;
            return res + SumNature(temp);
        }
        public static int SumCount(int a, int count = 1)
        {
            int res = a / 10;
            if (res == 0)
                return count;
            else
                return SumCount(res, count+1);
        }
    }
}
