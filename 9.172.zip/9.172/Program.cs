﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9._172
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] str = Console.ReadLine().Split(new string[] { " ", ",", "!", "?", ".", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            int maxLenght = str.Max(x => x.Length);
            Console.WriteLine(string.Join(" ", str.Where(x => x.Length == maxLenght).ToArray()));
        }
    }
}
